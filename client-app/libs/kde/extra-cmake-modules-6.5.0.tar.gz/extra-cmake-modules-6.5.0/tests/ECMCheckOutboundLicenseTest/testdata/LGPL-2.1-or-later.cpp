/*
    SPDX-FileCopyrightText: 2020 John Doe <nomail@example.com>
    SPDX-License-Identifier: LGPL-2.1-or-later
*/

// nothing in here, it is only a test
