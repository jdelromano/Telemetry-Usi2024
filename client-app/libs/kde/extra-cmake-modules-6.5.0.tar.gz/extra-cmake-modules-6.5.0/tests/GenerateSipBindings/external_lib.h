
#pragma once

class ExternalFwdDecl
{
public:
  ExternalFwdDecl(int value);

  int getValue() const;
private:
  int m_value;
};
