void make_test_file(const char *filename);
