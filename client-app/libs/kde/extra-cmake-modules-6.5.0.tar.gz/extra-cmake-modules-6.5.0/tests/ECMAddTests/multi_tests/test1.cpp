#include "testhelper.h"

int main()
{
    make_test_file("test1.txt");
    return 0;
}

