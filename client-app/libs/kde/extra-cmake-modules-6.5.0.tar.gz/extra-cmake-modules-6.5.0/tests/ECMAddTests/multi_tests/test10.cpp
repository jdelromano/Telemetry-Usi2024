#include "testhelper.h"

int main()
{
    make_test_file("test10.txt");
    return 0;
}

