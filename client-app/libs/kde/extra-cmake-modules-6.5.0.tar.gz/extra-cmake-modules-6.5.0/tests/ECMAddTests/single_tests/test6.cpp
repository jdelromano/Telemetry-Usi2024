void test_body();

int main()
{
    test_body();
    return 0;
}

