.. ecm-module:: ../../toolchain/Android.cmake
