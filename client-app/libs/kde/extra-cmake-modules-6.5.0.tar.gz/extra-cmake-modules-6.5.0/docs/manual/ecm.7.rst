.. ecm-manual-description: Extra CMake Modules

ecm(7)
******

.. only:: html or latex

   .. contents::

.. include:: ../../README.rst
  :start-line: 2
