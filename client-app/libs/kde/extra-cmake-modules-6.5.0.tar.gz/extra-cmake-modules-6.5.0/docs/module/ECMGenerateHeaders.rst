.. ecm-module:: ../../modules/ECMGenerateHeaders.cmake
