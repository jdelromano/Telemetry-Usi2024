.. ecm-module:: ../../modules/ECMQmlModule.cmake
