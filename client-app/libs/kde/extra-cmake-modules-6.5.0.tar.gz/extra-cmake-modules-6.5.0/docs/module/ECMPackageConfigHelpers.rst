.. ecm-module:: ../../modules/ECMPackageConfigHelpers.cmake
