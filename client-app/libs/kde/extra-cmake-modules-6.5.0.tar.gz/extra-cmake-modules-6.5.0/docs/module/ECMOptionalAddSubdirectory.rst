.. ecm-module:: ../../modules/ECMOptionalAddSubdirectory.cmake
