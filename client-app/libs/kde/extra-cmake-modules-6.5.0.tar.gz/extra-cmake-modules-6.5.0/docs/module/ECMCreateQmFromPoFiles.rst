.. ecm-module:: ../../modules/ECMCreateQmFromPoFiles.cmake
