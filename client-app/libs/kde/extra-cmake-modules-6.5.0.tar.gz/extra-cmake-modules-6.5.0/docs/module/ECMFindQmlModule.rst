.. ecm-module:: ../../modules/ECMFindQmlModule.cmake
