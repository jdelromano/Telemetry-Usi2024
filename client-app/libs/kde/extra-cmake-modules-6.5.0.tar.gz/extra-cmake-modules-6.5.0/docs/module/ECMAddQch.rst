.. ecm-module:: ../../modules/ECMAddQch.cmake
