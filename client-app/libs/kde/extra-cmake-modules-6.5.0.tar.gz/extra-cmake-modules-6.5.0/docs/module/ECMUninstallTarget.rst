.. ecm-module:: ../../modules/ECMUninstallTarget.cmake
