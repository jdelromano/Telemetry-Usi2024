.. ecm-module:: ../../modules/ECMInstallIcons.cmake
