.. ecm-module:: ../../modules/ECMCoverageOption.cmake
