.. ecm-module:: ../../modules/ECMAddAppIcon.cmake
