.. ecm-module:: ../../kde-modules/KDECMakeSettings.cmake
