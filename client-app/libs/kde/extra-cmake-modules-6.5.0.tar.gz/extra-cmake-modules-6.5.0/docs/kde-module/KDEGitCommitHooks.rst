.. ecm-module:: ../../kde-modules/KDEGitCommitHooks.cmake
