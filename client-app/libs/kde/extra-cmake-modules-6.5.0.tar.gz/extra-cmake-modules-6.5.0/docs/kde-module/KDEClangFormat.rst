.. ecm-module:: ../../kde-modules/KDEClangFormat.cmake
