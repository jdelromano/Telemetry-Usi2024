.. ecm-module:: ../../find-modules/FindSasl2.cmake
