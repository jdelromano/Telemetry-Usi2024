.. ecm-module:: ../../find-modules/Find7Zip.cmake
