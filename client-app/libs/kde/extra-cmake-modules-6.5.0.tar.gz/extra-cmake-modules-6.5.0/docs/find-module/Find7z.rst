.. ecm-module:: ../../find-modules/Find7z.cmake
