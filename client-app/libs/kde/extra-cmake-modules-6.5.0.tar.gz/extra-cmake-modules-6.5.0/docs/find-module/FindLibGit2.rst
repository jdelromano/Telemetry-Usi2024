.. ecm-module:: ../../find-modules/FindLibGit2.cmake
