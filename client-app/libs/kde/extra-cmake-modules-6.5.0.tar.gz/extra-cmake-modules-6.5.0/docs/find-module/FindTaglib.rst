.. ecm-module:: ../../find-modules/FindTaglib.cmake
