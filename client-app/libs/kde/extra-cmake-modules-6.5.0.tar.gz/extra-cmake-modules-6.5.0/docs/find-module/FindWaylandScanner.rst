.. ecm-module:: ../../find-modules/FindWaylandScanner.cmake
