.. ecm-module:: ../../find-modules/FindOpenEXR.cmake
